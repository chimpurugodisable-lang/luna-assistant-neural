package com.example.executor

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.example.intent.LunaIntent

class LunaAppLauncher(private val context: Context) {

    companion object {
        private const val TAG = "LunaAppLauncher"
        private var nextRequestCode = 1000
    }

    data class LaunchResult(
        val success: Boolean,
        val message: String
    )

    /**
     * Launch an activity from LUNA's foreground voice service.
     *
     * Android 14/15 tightened background-activity-launch rules.
     * On API 34+ use an explicit PendingIntent and opt in to the
     * background-activity-start privilege.
     */
    private fun launchActivity(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val backgroundStartMode =
                if (Build.VERSION.SDK_INT >= 36) {
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOW_ALWAYS
                } else {
                    ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                }

            val creatorOptions = ActivityOptions.makeBasic().apply {
                setPendingIntentCreatorBackgroundActivityStartMode(backgroundStartMode)
            }

            val requestCode = synchronized(LunaAppLauncher::class.java) {
                nextRequestCode =
                    if (nextRequestCode == Int.MAX_VALUE) 1000 else nextRequestCode + 1
                nextRequestCode
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                creatorOptions.toBundle()
            )

            val senderOptions = ActivityOptions.makeBasic().apply {
                setPendingIntentBackgroundActivityStartMode(backgroundStartMode)
            }

            try {
                pendingIntent.send(senderOptions.toBundle())
            } finally {
                pendingIntent.cancel()
            }
        } else {
            context.startActivity(intent)
        }
    }

    /**
     * Attempts to launch an installed application by query name or package.
     */
    fun launchApp(appName: String, suggestedPackage: String? = null): LaunchResult {
        val pm = context.packageManager

        if (!suggestedPackage.isNullOrEmpty()) {
            val intent = pm.getLaunchIntentForPackage(suggestedPackage)
            if (intent != null) {
                try {
                    launchActivity(intent)
                    val friendlyName = when (suggestedPackage) {
                        "com.whatsapp.w4b" -> "WhatsApp Business"
                        "com.whatsapp" -> "WhatsApp"
                        "com.android.chrome" -> "Chrome"
                        "com.facebook.katana" -> "Facebook"
                        "com.google.android.youtube" -> "YouTube"
                        "com.spotify.music" -> "Spotify"
                        else -> appName
                    }
                    return LaunchResult(true, "Opening $friendlyName.")
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to launch suggested package $suggestedPackage", e)
                }
            }
        }

        try {
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val queryClean = appName.trim().lowercase()

            for (appInfo in installedApps) {
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                if (label == queryClean || label.contains(queryClean) || queryClean.contains(label)) {
                    val intent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (intent != null) {
                        try {
                            launchActivity(intent)
                            val appLabel = pm.getApplicationLabel(appInfo).toString()
                            return LaunchResult(true, "Opening $appLabel.")
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to launch matched package ${appInfo.packageName}", e)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying applications", e)
        }

        return LaunchResult(false, "I couldn't open $appName on your phone.")
    }

    /**
     * Opens real Android Settings categories.
     */
    fun openSettings(category: LunaIntent.SettingsCategory): LaunchResult {
        val action = when (category) {
            LunaIntent.SettingsCategory.MAIN -> Settings.ACTION_SETTINGS
            LunaIntent.SettingsCategory.WIFI -> Settings.ACTION_WIFI_SETTINGS
            LunaIntent.SettingsCategory.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            LunaIntent.SettingsCategory.DISPLAY -> Settings.ACTION_DISPLAY_SETTINGS
            LunaIntent.SettingsCategory.NOTIFICATIONS -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            LunaIntent.SettingsCategory.SOUND -> Settings.ACTION_SOUND_SETTINGS
            LunaIntent.SettingsCategory.APPS -> Settings.ACTION_APPLICATION_SETTINGS
            LunaIntent.SettingsCategory.BATTERY -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                if (category == LunaIntent.SettingsCategory.NOTIFICATIONS) {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                }
            }
            launchActivity(intent)

            val catName = when (category) {
                LunaIntent.SettingsCategory.WIFI -> "Wi-Fi settings"
                LunaIntent.SettingsCategory.BLUETOOTH -> "Bluetooth settings"
                LunaIntent.SettingsCategory.DISPLAY -> "display settings"
                LunaIntent.SettingsCategory.NOTIFICATIONS -> "notification settings"
                LunaIntent.SettingsCategory.SOUND -> "sound settings"
                LunaIntent.SettingsCategory.BATTERY -> "battery settings"
                LunaIntent.SettingsCategory.APPS -> "app settings"
                LunaIntent.SettingsCategory.MAIN -> "Settings"
            }
            LaunchResult(true, "Opening $catName.")
        } catch (e: Exception) {
            Log.e(TAG, "Error opening settings $category", e)
            LaunchResult(false, "Could not open settings.")
        }
    }
}
