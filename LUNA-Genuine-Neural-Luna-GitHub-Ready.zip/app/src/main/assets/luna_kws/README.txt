LUNA genuine neural wake-word engine

Exact wake word: Luna
Engine: Sherpa-ONNX Zipformer GigaSpeech keyword spotter
Inference: fully on-device / offline

The GitHub Actions build downloads the official Sherpa-ONNX Android AAR and
GigaSpeech KWS model, generates the BPE keyword tokens for "Luna", verifies
all model files, and packages them into the APK.

No SpeechRecognizer is used for wake detection. SpeechRecognizer is used only
after the neural model has detected "Luna", to capture the user's command.
