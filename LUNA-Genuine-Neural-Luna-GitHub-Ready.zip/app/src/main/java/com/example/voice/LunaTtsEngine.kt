package com.example.voice

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID

/**
 * Text-to-speech engine for LUNA.
 * Handles speech synthesis with utterance tracking, state synchronization,
 * watchdog timeouts, and audio-feedback prevention.
 */
class LunaTtsEngine(
    private val context: Context,
    private val onInitComplete: (success: Boolean) -> Unit = {}
) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "LunaTtsEngine"
    }

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private val pendingCompletions = mutableMapOf<String, () -> Unit>()
    private val watchdogRunnables = mutableMapOf<String, Runnable>()

    var isSpeaking: Boolean = false
        private set

    var onSpeakingStateChanged: ((isSpeaking: Boolean) -> Unit)? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to instantiate TextToSpeech", e)
            onInitComplete(false)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Language US not supported, falling back to default locale")
                tts?.language = Locale.getDefault()
            }
            tts?.setPitch(1.05f)
            tts?.setSpeechRate(1.0f)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    Log.d(TAG, "TTS onStart utteranceId: $utteranceId")
                    isSpeaking = true
                    mainHandler.post { onSpeakingStateChanged?.invoke(true) }
                }

                override fun onDone(utteranceId: String?) {
                    Log.d(TAG, "TTS onDone utteranceId: $utteranceId")
                    handleUtteranceFinished(utteranceId)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    Log.w(TAG, "TTS onError utteranceId: $utteranceId")
                    handleUtteranceFinished(utteranceId)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    Log.w(TAG, "TTS onError utteranceId: $utteranceId with code: $errorCode")
                    handleUtteranceFinished(utteranceId)
                }
            })

            isInitialized = true
            Log.i(TAG, "TTS initialized successfully")
            onInitComplete(true)
        } else {
            Log.e(TAG, "TTS initialization failed with code $status")
            isInitialized = false
            onInitComplete(false)
        }
    }

    private fun handleUtteranceFinished(utteranceId: String?) {
        val action: (() -> Unit)?
        synchronized(pendingCompletions) {
            utteranceId?.let { id ->
                watchdogRunnables.remove(id)?.let { mainHandler.removeCallbacks(it) }
            }
            action = if (utteranceId != null) pendingCompletions.remove(utteranceId) else null
            if (pendingCompletions.isEmpty()) {
                isSpeaking = false
            }
        }

        mainHandler.post {
            onSpeakingStateChanged?.invoke(isSpeaking)
            action?.invoke()
        }
    }

    /**
     * Speaks the given text and optionally triggers a callback when completed.
     * Includes a watchdog timer so that if TTS drops callbacks or audio fails,
     * the app never hangs in speaking state.
     */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isInitialized || tts == null || text.isBlank()) {
            Log.w(TAG, "TTS not ready or text blank. Skipping voice output: $text")
            isSpeaking = false
            onSpeakingStateChanged?.invoke(false)
            onDone?.invoke()
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        if (onDone != null) {
            synchronized(pendingCompletions) {
                pendingCompletions[utteranceId] = onDone
            }
        }

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        // Set safety watchdog timeout based on length of text
        val timeoutMs = (text.length * 85L + 2500L).coerceIn(2500L, 18000L)
        val watchdog = Runnable {
            Log.w(TAG, "TTS watchdog timeout fired for utterance: $utteranceId")
            handleUtteranceFinished(utteranceId)
        }

        synchronized(pendingCompletions) {
            watchdogRunnables[utteranceId] = watchdog
        }
        mainHandler.postDelayed(watchdog, timeoutMs)

        isSpeaking = true
        onSpeakingStateChanged?.invoke(true)

        val result = try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        } catch (e: Exception) {
            Log.e(TAG, "Exception calling tts.speak", e)
            TextToSpeech.ERROR
        }

        if (result != TextToSpeech.SUCCESS) {
            Log.w(TAG, "tts.speak returned error code $result for utterance: $utteranceId")
            handleUtteranceFinished(utteranceId)
        }
    }

    /**
     * Stops current speech immediately and clears all pending callbacks safely.
     */
    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping TTS", e)
        } finally {
            isSpeaking = false
            synchronized(pendingCompletions) {
                for (watchdog in watchdogRunnables.values) {
                    mainHandler.removeCallbacks(watchdog)
                }
                watchdogRunnables.clear()

                val actionsToRun = pendingCompletions.values.toList()
                pendingCompletions.clear()
                mainHandler.post {
                    onSpeakingStateChanged?.invoke(false)
                    for (action in actionsToRun) {
                        try {
                            action()
                        } catch (e: Exception) {
                            Log.w(TAG, "Error invoking cancelled speech callback", e)
                        }
                    }
                }
            }
        }
    }

    /**
     * Releases TTS resources.
     */
    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
            tts = null
            isInitialized = false
        } catch (e: Exception) {
            Log.e(TAG, "Error shutting down TTS", e)
        }
    }
}
