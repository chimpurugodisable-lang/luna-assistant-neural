package com.example.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.KeywordSpotter
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Genuine on-device neural wake-word engine for the exact keyword "Luna".
 *
 * AudioRecord -> Sherpa-ONNX Zipformer KWS -> keyword token match -> callback.
 * No SpeechRecognizer, RMS threshold, syllable counting, cloud service, or
 * network connection is used for wake detection.
 */
class LunaWakeWordEngine(
    private val context: Context,
    private val onWakeWordDetected: (wakePhrase: String) -> Unit,
    private val onError: (message: String) -> Unit
) {
    companion object {
        private const val TAG = "LunaWakeWordEngine"
        private const val SAMPLE_RATE = 16_000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val BUFFER_MULTIPLIER = 2
        private const val MODEL_DIR = "luna_kws"
        private const val ENCODER = "$MODEL_DIR/encoder.int8.onnx"
        private const val DECODER = "$MODEL_DIR/decoder.int8.onnx"
        private const val JOINER = "$MODEL_DIR/joiner.int8.onnx"
        private const val TOKENS = "$MODEL_DIR/tokens.txt"
        private const val KEYWORDS = "$MODEL_DIR/keywords.txt"
        private const val KEYWORD_THRESHOLD = 0.25f
        private const val KEYWORD_SCORE = 1.5f
        private const val COOLDOWN_MS = 1500L
    }

    private val running = AtomicBoolean(false)
    private val mutedForTts = AtomicBoolean(false)
    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null
    private var spotter: KeywordSpotter? = null
    private var stream: OnlineStream? = null
    private var lastDetectionAt = 0L

    var isConfigValid: Boolean = false
        private set

    init {
        validateAssets()
    }

    fun validateAssets(): Boolean {
        return try {
            val files = context.assets.list(MODEL_DIR)?.toSet() ?: emptySet()
            val required = setOf(
                "encoder.int8.onnx",
                "decoder.int8.onnx",
                "joiner.int8.onnx",
                "tokens.txt",
                "keywords.txt"
            )
            isConfigValid = required.all(files::contains)
            Log.i(TAG, "Neural KWS assets: ${files.joinToString()}, valid=$isConfigValid")
            isConfigValid
        } catch (e: Exception) {
            Log.e(TAG, "Could not validate neural KWS assets", e)
            isConfigValid = false
            false
        }
    }

    fun setTtsSpeaking(speaking: Boolean) {
        mutedForTts.set(speaking)
    }

    @Synchronized
    fun startListening() {
        if (running.get()) return
        if (!validateAssets()) {
            onError("Genuine Luna neural KWS model is missing from the APK")
            return
        }

        stopListening()

        try {
            initializeSpotter()
            val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            if (minBuffer <= 0) throw IllegalStateException("Invalid AudioRecord buffer size")
            val bufferSize = maxOf(minBuffer * BUFFER_MULTIPLIER, SAMPLE_RATE / 5)

            audioRecord = createAudioRecord(bufferSize)
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("AudioRecord could not initialize")
            }

            audioRecord!!.startRecording()
            running.set(true)
            mutedForTts.set(false)

            workerThread = Thread({ processAudioStream(bufferSize) }, "LunaNeuralKws").apply {
                priority = Thread.NORM_PRIORITY + 1
                start()
            }
            Log.i(TAG, "Genuine neural Luna KWS started")
        } catch (e: SecurityException) {
            onError("Microphone permission missing")
            stopListening()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start neural Luna KWS", e)
            onError("Neural wake-word engine error: ${e.localizedMessage ?: "unknown error"}")
            stopListening()
        }
    }

    private fun initializeSpotter() {
        val modelConfig = OnlineModelConfig(
            transducer = OnlineTransducerModelConfig(
                encoder = ENCODER,
                decoder = DECODER,
                joiner = JOINER
            ),
            tokens = TOKENS,
            numThreads = 1,
            debug = false,
            provider = "cpu"
        )
        val config = KeywordSpotterConfig(
            featConfig = FeatureConfig(SAMPLE_RATE, 80),
            modelConfig = modelConfig,
            maxActivePaths = 4,
            keywordsFile = KEYWORDS,
            keywordsScore = KEYWORD_SCORE,
            keywordsThreshold = KEYWORD_THRESHOLD,
            numTrailingBlanks = 1
        )
        spotter = KeywordSpotter(context.assets, config)
        stream = spotter!!.createStream()
    }

    private fun createAudioRecord(bufferSize: Int): AudioRecord {
        val preferred = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )
        } catch (_: Exception) {
            null
        }
        if (preferred?.state == AudioRecord.STATE_INITIALIZED) return preferred
        preferred?.release()

        return AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            bufferSize
        )
    }

    private fun processAudioStream(bufferSize: Int) {
        val pcm = ShortArray(bufferSize / 2)
        val floatSamples = FloatArray(pcm.size)

        while (running.get()) {
            val record = audioRecord ?: break
            val read = try {
                record.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
            } catch (e: Exception) {
                Log.w(TAG, "AudioRecord read failed", e)
                -1
            }

            if (read <= 0) continue
            if (mutedForTts.get()) continue

            for (i in 0 until read) {
                floatSamples[i] = pcm[i] / 32768.0f
            }

            val activeStream = stream ?: continue
            val activeSpotter = spotter ?: continue
            activeStream.acceptWaveform(floatSamples.copyOf(read), SAMPLE_RATE)

            while (activeSpotter.isReady(activeStream)) {
                activeSpotter.decode(activeStream)
                val result = activeSpotter.getResult(activeStream)
                val keyword = result.keyword.trim().lowercase()
                if (keyword == "luna") {
                    activeSpotter.reset(activeStream)
                    triggerDetection()
                    break
                }
            }
        }
    }

    private fun triggerDetection() {
        val now = System.currentTimeMillis()
        if (now - lastDetectionAt < COOLDOWN_MS) return
        if (!running.get() || mutedForTts.get()) return
        lastDetectionAt = now
        mutedForTts.set(true)
        Log.i(TAG, "Neural wake word detected: Luna")
        onWakeWordDetected("Luna")
    }

    @Synchronized
    fun stopListening() {
        running.set(false)
        try {
            workerThread?.interrupt()
            workerThread?.join(250)
        } catch (_: Exception) {
        }
        workerThread = null

        try {
            audioRecord?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
                it.release()
            }
        } catch (_: Exception) {
        }
        audioRecord = null

        try {
            stream?.release()
        } catch (_: Exception) {
        }
        stream = null

        try {
            spotter?.release()
        } catch (_: Exception) {
        }
        spotter = null
    }

    fun isListening(): Boolean = running.get()
}
