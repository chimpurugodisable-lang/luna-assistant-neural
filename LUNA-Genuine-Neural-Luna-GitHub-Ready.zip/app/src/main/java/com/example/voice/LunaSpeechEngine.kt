package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Speech recognition engine for LUNA.
 *
 * Two modes are supported:
 *  - wake mode: continuously looks for the exact wake phrase and restarts sessions
 *    automatically. On-device recognition is preferred when Android provides it.
 *  - command mode: gives the user a generous speaking window and preserves partials.
 *
 * This is deliberately separate from the acoustic wake detector so Android's own
 * speech model can confirm the spoken word "Luna" instead of treating arbitrary
 * loud/background audio as a wake event.
 */
class LunaSpeechEngine(
    private val context: Context,
    private val listener: SpeechEngineListener
) {

    interface SpeechEngineListener {
        fun onReadyForCommand()
        fun onRmsChanged(rmsdB: Float)
        fun onPartialResult(partialText: String)
        fun onFinalResult(spokenText: String)
        fun onError(errorCode: Int, message: String)
        fun onWakeWordDetected(wakePhrase: String)
    }

    companion object {
        private const val TAG = "LunaSpeechEngine"

        // Android may impose its own recognizer limits; this watchdog is intentionally
        // longer so LUNA does not cancel a session prematurely.
        private const val COMMAND_WATCHDOG_MS = 60_000L
        private const val WAKE_SESSION_WATCHDOG_MS = 20_000L
        private const val COMMAND_MINIMUM_LENGTH_MS = 3_000L
        private const val COMMAND_COMPLETE_SILENCE_MS = 6_000L
        private const val COMMAND_POSSIBLY_COMPLETE_SILENCE_MS = 4_500L
        private const val WAKE_COMPLETE_SILENCE_MS = 2_000L
        private const val WAKE_POSSIBLY_COMPLETE_SILENCE_MS = 1_500L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var watchdogRunnable: Runnable? = null
    private var wakeMode = false
    private var wakeRestartPending = false

    var isListening: Boolean = false
        private set

    init {
        mainHandler.post { ensureRecognizerReady() }
    }

    private fun ensureRecognizerReady(): Boolean {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e(TAG, "Speech recognition is not available on this device")
            return false
        }

        if (speechRecognizer != null) return true

        return try {
            speechRecognizer = if (
                android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
            ) {
                Log.d(TAG, "Creating ON-DEVICE SpeechRecognizer")
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } else {
                Log.d(TAG, "Creating system SpeechRecognizer")
                SpeechRecognizer.createSpeechRecognizer(context)
            }.apply {
                setRecognitionListener(createListener())
            }
            Log.d(TAG, "SpeechRecognizer initialized successfully")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create SpeechRecognizer", e)
            speechRecognizer = null
            false
        }
    }

    private fun createListener(): RecognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            isListening = true
            scheduleWatchdog(if (wakeMode) WAKE_SESSION_WATCHDOG_MS else COMMAND_WATCHDOG_MS)
            if (!wakeMode) listener.onReadyForCommand()
            Log.d(TAG, "SpeechRecognizer ready; wakeMode=$wakeMode")
        }

        override fun onBeginningOfSpeech() {
            // Once the user starts talking, give the command a full minute.
            scheduleWatchdog(if (wakeMode) WAKE_SESSION_WATCHDOG_MS else COMMAND_WATCHDOG_MS)
            Log.d(TAG, "SpeechRecognizer: beginning of speech; wakeMode=$wakeMode")
        }

        override fun onRmsChanged(rmsdB: Float) {
            listener.onRmsChanged(rmsdB)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            scheduleWatchdog(8_000L)
            Log.d(TAG, "SpeechRecognizer: end of speech; decoding")
        }

        override fun onError(error: Int) {
            cancelWatchdog()
            isListening = false
            val errorMsg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out"
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording busy"
                SpeechRecognizer.ERROR_CLIENT -> "Client recognition error"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permission error"
                SpeechRecognizer.ERROR_NETWORK -> "Network issue"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                SpeechRecognizer.ERROR_SERVER -> "Server error"
                else -> "Recognition error: $error"
            }
            Log.w(TAG, "SpeechRecognizer onError: $error ($errorMsg), wakeMode=$wakeMode")

            try { speechRecognizer?.cancel() } catch (_: Exception) {}

            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                error == SpeechRecognizer.ERROR_CLIENT ||
                error == SpeechRecognizer.ERROR_SERVER
            ) {
                destroyRecognizerInternal()
            }

            if (wakeMode && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                // Wake mode is intentionally self-healing: Android recognition sessions
                // end periodically, so start a fresh one instead of leaving LUNA deaf.
                scheduleWakeRestart()
            } else if (!wakeMode) {
                listener.onError(error, errorMsg)
            }
        }

        override fun onResults(results: Bundle?) {
            cancelWatchdog()
            isListening = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()
            val text = matches.firstOrNull()?.trim().orEmpty()
            Log.i(TAG, "SpeechRecognizer onResults: \"$text\" wakeMode=$wakeMode")

            try { speechRecognizer?.cancel() } catch (_: Exception) {}

            if (wakeMode) {
                val normalized = normalize(text)
                val hasHeyLuna = containsWakePhrase(normalized, "hey luna")
                val hasLuna = containsWakePhrase(normalized, "luna")
                if (hasHeyLuna || hasLuna) {
                    wakeRestartPending = false
                    val phrase = if (hasHeyLuna) "Hey Luna" else "Luna"
                    wakeMode = false
                    listener.onWakeWordDetected(phrase)
                } else {
                    scheduleWakeRestart()
                }
            } else if (text.isNotEmpty()) {
                listener.onFinalResult(text)
            } else {
                listener.onError(SpeechRecognizer.ERROR_NO_MATCH, "No words heard")
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim().orEmpty()
            if (text.isEmpty()) return

            listener.onPartialResult(text)

            // In wake mode, a partial containing the exact wake word is strong enough
            // to finish the wake session early. This reduces latency and avoids waiting
            // for Android's end-of-speech decision.
            if (wakeMode && containsWakePhrase(normalize(text), "luna")) {
                try { speechRecognizer?.stopListening() } catch (_: Exception) {}
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    /** Starts the hands-free wake-word recognizer. */
    fun startWakeWordListening() {
        mainHandler.post {
            cancelWatchdog()
            wakeRestartPending = false
            wakeMode = true
            startRecognitionInternal(isWake = true)
        }
    }

    /** Starts the user-command recognizer. */
    fun startListening() {
        mainHandler.post {
            cancelWatchdog()
            wakeRestartPending = false
            wakeMode = false
            startRecognitionInternal(isWake = false)
        }
    }

    private fun startRecognitionInternal(isWake: Boolean) {
        if (!ensureRecognizerReady()) {
            if (isWake) {
                listener.onError(-1, "Speech recognition unavailable; acoustic fallback required")
            } else {
                listener.onError(-1, "Speech recognition unavailable on device")
            }
            return
        }

        try {
            speechRecognizer?.cancel()
            isListening = false

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, if (isWake) 5 else 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,
                    if (isWake) 500L else COMMAND_MINIMUM_LENGTH_MS)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                    if (isWake) WAKE_COMPLETE_SILENCE_MS else COMMAND_COMPLETE_SILENCE_MS)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,
                    if (isWake) WAKE_POSSIBLY_COMPLETE_SILENCE_MS else COMMAND_POSSIBLY_COMPLETE_SILENCE_MS)
                if (!isWake) {
                    putExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES, true)
                }
            }

            scheduleWatchdog(if (isWake) WAKE_SESSION_WATCHDOG_MS else COMMAND_WATCHDOG_MS)
            speechRecognizer?.startListening(intent)
            Log.d(TAG, "startListening initiated; wakeMode=$isWake")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognition", e)
            cancelWatchdog()
            isListening = false
            if (isWake) {
                scheduleWakeRestart()
            } else {
                destroyRecognizerInternal()
                listener.onError(-1, "Unable to start speech recognizer: ${e.message}")
            }
        }
    }

    private fun scheduleWakeRestart() {
        if (!wakeMode || wakeRestartPending) return
        wakeRestartPending = true
        mainHandler.postDelayed({
            wakeRestartPending = false
            if (wakeMode) startRecognitionInternal(isWake = true)
        }, 350L)
    }

    private fun scheduleWatchdog(durationMs: Long) {
        cancelWatchdog()
        val runnable = Runnable {
            Log.w(TAG, "SpeechRecognizer watchdog timeout fired; wakeMode=$wakeMode")
            isListening = false
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
            if (wakeMode) {
                scheduleWakeRestart()
            } else {
                listener.onError(SpeechRecognizer.ERROR_SPEECH_TIMEOUT, "Listening timed out")
            }
        }
        watchdogRunnable = runnable
        mainHandler.postDelayed(runnable, durationMs)
    }

    private fun cancelWatchdog() {
        watchdogRunnable?.let(mainHandler::removeCallbacks)
        watchdogRunnable = null
    }

    fun reset() {
        mainHandler.post {
            cancelWatchdog()
            wakeRestartPending = false
            wakeMode = false
            isListening = false
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
        }
    }

    fun stopListening() {
        mainHandler.post {
            cancelWatchdog()
            wakeRestartPending = false
            try { speechRecognizer?.stopListening() } catch (_: Exception) {}
            isListening = false
        }
    }

    private fun normalize(value: String): String = value
        .lowercase(java.util.Locale.US)
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsWakePhrase(text: String, phrase: String): Boolean {
        val padded = " $text "
        return padded.contains(" $phrase ")
    }

    private fun destroyRecognizerInternal() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying recognizer", e)
        } finally {
            speechRecognizer = null
            isListening = false
        }
    }

    fun destroy() {
        mainHandler.post {
            cancelWatchdog()
            wakeMode = false
            wakeRestartPending = false
            destroyRecognizerInternal()
        }
    }
}
