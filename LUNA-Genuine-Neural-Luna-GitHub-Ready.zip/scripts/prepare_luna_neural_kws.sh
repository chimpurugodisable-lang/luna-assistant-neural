#!/usr/bin/env bash
set -euo pipefail

VERSION="1.13.8"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets/luna_kws"
LIBS="$ROOT/app/libs"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$ASSETS" "$LIBS"

curl -fL --retry 5 --retry-all-errors \
  "https://github.com/k2-fsa/sherpa-onnx/releases/download/v${VERSION}/sherpa-onnx-kws-zipformer-gigaspeech-3.3M-2024-01-01.tar.bz2" \
  -o "$TMP/kws.tar.bz2"
tar -xjf "$TMP/kws.tar.bz2" -C "$TMP"
MODEL_DIR="$TMP/sherpa-onnx-kws-zipformer-gigaspeech-3.3M-2024-01-01"

cp "$MODEL_DIR/encoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx" "$ASSETS/encoder.int8.onnx"
cp "$MODEL_DIR/decoder-epoch-12-avg-2-chunk-16-left-64.int8.onnx" "$ASSETS/decoder.int8.onnx"
cp "$MODEL_DIR/joiner-epoch-12-avg-2-chunk-16-left-64.int8.onnx" "$ASSETS/joiner.int8.onnx"
cp "$MODEL_DIR/tokens.txt" "$ASSETS/tokens.txt"

python3 -m pip install --quiet --upgrade "sherpa-onnx==${VERSION}"
printf 'Luna\n' > "$TMP/keywords_raw.txt"
sherpa-onnx-cli text2token \
  --tokens "$ASSETS/tokens.txt" \
  --tokens-type bpe \
  --bpe-model "$MODEL_DIR/bpe.model" \
  "$TMP/keywords_raw.txt" "$ASSETS/keywords.txt"

python3 - <<'PY' "$ASSETS/keywords.txt"
from pathlib import Path
import sys
p=Path(sys.argv[1])
lines=[x.strip() for x in p.read_text().splitlines() if x.strip()]
if not lines or not any('L' in x.upper() for x in lines):
    raise SystemExit('Generated Luna keyword tokens are empty/invalid')
p.write_text(lines[0]+'\n')
print('Luna keyword tokens:', lines[0])
PY

curl -fL --retry 5 --retry-all-errors \
  "https://github.com/k2-fsa/sherpa-onnx/releases/download/v${VERSION}/sherpa-onnx-${VERSION}.aar" \
  -o "$LIBS/sherpa-onnx-${VERSION}.aar"

cat > "$ASSETS/MODEL_SOURCE.txt" <<TXT
Official Sherpa-ONNX GigaSpeech Zipformer KWS model
Version: ${VERSION}
Keyword: Luna
Model source: https://github.com/k2-fsa/sherpa-onnx
The keyword list is generated from the official model BPE vocabulary during the build.
TXT

echo "Prepared genuine neural Luna KWS assets."
ls -lh "$ASSETS" "$LIBS"
