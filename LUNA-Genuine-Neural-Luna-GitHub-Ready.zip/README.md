# LUNA Android Voice Assistant

This repository contains the Android LUNA voice assistant generated from the AI Studio project.

## GitHub APK build

Push to `main` or run the **Build LUNA APK** workflow manually. GitHub Actions installs Gradle 9.3.1, builds the debug APK, and uploads `LUNA-debug-APK` as a workflow artifact.

## Voice improvements in this build

- Command listening watchdog increased to 30 seconds.
- Speech recognition is given longer completion-silence windows so normal pauses do not end a command too quickly.
- Wake-word detection now uses an adaptive noise floor instead of a fixed microphone threshold.
- Wake-word candidates require a compact speech-like segment and multiple energy peaks, reducing random background-noise triggers.
- A short wake-word cooldown prevents repeated triggers from the same sound.

## Important

Android still controls microphone access. LUNA must have `RECORD_AUDIO` permission, and the microphone foreground service is started while the app is visible. Android requires the microphone foreground-service type and permission for this use case on recent Android versions.

The debug build can operate with LUNA's offline fallback responses when no Gemini key is configured. Do not commit a real API key to GitHub.

## Voice / Wake-Word Upgrade

This build uses a two-tier wake system:

1. Android's SpeechRecognizer is the primary wake detector and prefers on-device recognition when the device exposes it. LUNA only accepts a wake result containing the exact word `Luna` or phrase `Hey Luna`.
2. The adaptive AudioRecord detector remains as a fallback when no speech-recognition service is available. It learns the local noise floor instead of using one fixed microphone threshold.

Command listening now uses a 60-second application watchdog and longer silence windows. Android's speech service may still impose device/service-specific limits, so these values are intentionally generous but are not a guarantee of a 60-second continuous recording session.

The project also declares the Android speech `RecognitionService` query required for apps targeting Android 11+ that interact with speech-recognition services.

## Genuine Neural Luna Wake Word

The wake path now uses Sherpa-ONNX's official Zipformer GigaSpeech keyword-spotting model. The exact keyword is **Luna**. GitHub Actions downloads the official Android runtime and model, generates the correct BPE keyword tokens from the model vocabulary, verifies the files, and packages them into the APK. Wake detection is local and does not use Android SpeechRecognizer, RMS thresholds, syllable heuristics, or a cloud service.
